<?php
 $username = "saeed7654";
 $getCitiesUrl = "https://secure.geonames.org/searchJSON?country=GB&featureClass=P&maxRows=1000&";
 $getCityUrl = "https://secure.geonames.org/getJSON?";


?>
